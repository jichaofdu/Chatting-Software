package com.example.isweixin;

public class Friend {
	private String weixinID;
	private String name;
	private String lastContent;
	private String lastTime;
	private String TxPath;

	public String getWeixinID() {
		return weixinID;
	}

	public void setWeixinID1(String weixinID) {
		this.weixinID = weixinID;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getLastContent() {
		return lastContent;
	}

	public void setLastContent(String lastContent) {
		this.lastContent = lastContent;
	}

	public String getLastTime() {
		return lastTime;
	}

	public void setLastTime(String lastTime) {
		this.lastTime = lastTime;
	}

	public String getTxPath() {
		return TxPath;
	}

	public void setTxPath(String txPath) {
		TxPath = txPath;
	}
	
}
