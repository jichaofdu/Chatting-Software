package com.example.isweixin;

public interface OnViewChangeListener {
	void OnViewChange(int view);
}
